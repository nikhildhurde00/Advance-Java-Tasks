public class user {
    private int id;
    private String username;
    private  String pass;
    private String role;

    public user(int id,String username,String pass) {
        this.id = id;
        this.username = username;
        this.pass = pass;
        role="USER";
    }
    public  int get_id(){
        return id;
    }
    public String get_username(){
        return username;
    }
    public String get_pass(){
        return pass;
    }
    public String get_role(){
        return role;
    }
}
