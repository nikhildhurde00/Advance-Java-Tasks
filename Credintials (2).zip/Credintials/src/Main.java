import java.sql.SQLException;
import java.util.Scanner;

class Main {
    public static void main(String[] args) throws SQLException {
        Scanner sc = new Scanner(System.in);
        boolean bl = true;
        while (bl) {
            System.out.println("Welcome to my APP !");
            System.out.println("1.Register \t 2.Login \t 3.EXIT  ");
            int choice = sc.nextInt();
            if (choice < 1 || choice > 3) return;
            switch (choice) {
                case 1 -> {
                    System.out.println("Create New Account!");
                    System.out.println("Your id ");
                    int id = sc.nextInt();
                    System.out.println("Your username ");
                    String username = sc.next();
                    System.out.println("Your password");
                    String pass = sc.next();
                    user user = new user(id, username, pass);
                    UserMethods.adduser(user);
                }

                case 2 ->{
                    System.out.println("ENTEr YOUR USERNAME:");
                    String username=sc.next();
                    System.out.println("ENTER YOUR PASSWORD:");
                    String password= sc.next();
                    UserMethods.LOGIN(username ,password);
                }

                case 3-> {
                    System.out.println("Thank you for visiting !");
                    bl = false;
                }

                default -> {
                    System.out.println("INVALID CHOICE....!");
                }


            }
        }
    }
}