import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserMethods {

    public static void adduser (user u) throws SQLException {
    ArrayList<user> al=new ArrayList<>();
        Connection conn=DB.connect();
        String insert = query.insert;
        PreparedStatement stmt1= conn.prepareStatement(insert);
        stmt1.setInt(1,u.get_id());
        stmt1.setString(2,u.get_username());
        stmt1.setString(3,u.get_pass());
        stmt1.setString(4,u.get_role());
        int i= stmt1.executeUpdate();

        if(i>0){
            System.out.println("USER REGISTERED SUCCESFULLY !");
            System.out.println("USERNAME:"+u.get_username()+"\tPASSWORD:"+u.get_pass());

        }else {
            System.out.println("SOME ERROR IN REGISTER !");
        }
    }

    public static void LOGIN(String username, String password) throws SQLException{
        boolean b=true;
        Connection conn=DB.connect();
        String loginQuery=query.loginQuery;
        PreparedStatement stmt=conn.prepareStatement(loginQuery);
        ResultSet rs=stmt.executeQuery();
        while(rs.next()){
            if(username.trim().equals(rs.getString(1).trim()) && password.trim().equals(rs.getString(2).trim()) && "USER".equals(rs.getString(3))){
                System.out.println("USER LOGIN SUCCESSfully");
                b=false;
                break;
            }else if( rs.getString(3).equals("ADMIN") && username.trim().equals(rs.getString(1).trim()) && password.trim().equals(rs.getString(2).trim())){
                System.out.println("ADMIN LOGIN SUCCESSFULLY");
                System.out.println("ALL EMPLOYEE'S LIST--->");
                showUsers();
                b=false;
                break;
            }

        }
        if(b)
        System.out.println("INVALID CREDINTIALS\n");
    }

    public static void showUsers() throws SQLException {
    ArrayList<user> u=new ArrayList<>();
    Connection conn=DB.connect();
    String select=query.select;
    PreparedStatement stmt=conn.prepareStatement(select);
       ResultSet rs = stmt.executeQuery();
       while(rs.next()){
           user us = new user(rs.getInt(1),rs.getString(2),rs.getString(3));
           u.add(us);
       }
        for (user val : u) {
            System.out.println("ID:"+val.get_id()+"\tUsername:"+val.get_username()+"\tPassword: "+val.get_pass()+"\tROLE: "+val.get_role());
        }
        System.out.println("\n");
    }
}
