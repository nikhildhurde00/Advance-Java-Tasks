public class query {
    static String insert="insert into users values(?,?,?,?);";
    static String select="select * from users;";
    static String loginQuery="select username , password , role from users;";

}
