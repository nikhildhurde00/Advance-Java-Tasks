public class Employee{
    private  int Emp_id;
    private String Emp_fname;
    private String Emp_lname;
    private int Emp_salary;
    private int Emp_deptid;

    public Employee(int Emp_id,String Emp_fname,String Emp_lname, int Emp_salary,int Emp_deptid){
            this.Emp_id=Emp_id;
            this.Emp_fname=Emp_fname;
            this.Emp_lname=Emp_lname;
            this.Emp_salary=Emp_salary;
            this.Emp_deptid=Emp_deptid;
         }

         public int getEmp_id(){
            return Emp_id;
         }
         public String getEmp_fname(){
            return Emp_fname;
         }
         public String getEmp_lname(){
            return Emp_lname;
         }
         public int getEmp_salary(){
            return Emp_salary;
         }
         public int getEmp_deptid(){
            return Emp_deptid;
         }


         public String toString(){
            return "Employee[id="+Emp_id+",fname="+Emp_fname+",lname="+Emp_lname+",salary="+Emp_salary+",dept_id="+Emp_deptid+"]";
         }



}
