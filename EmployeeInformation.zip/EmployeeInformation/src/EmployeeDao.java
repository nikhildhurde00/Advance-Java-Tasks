
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeDao {
    //To insert data into database 
    public static void createEmployee(Employee Emp) throws  SQLException{
    Connection con=DB.connect();
    String query=Query.insert;
    PreparedStatement ps=con.prepareStatement(query);

    ps.setInt(1,Emp.getEmp_id());
    ps.setString(2,Emp.getEmp_fname());
    ps.setString(3,Emp.getEmp_lname());
    ps.setInt(4,Emp.getEmp_salary());
    ps.setInt(5,Emp.getEmp_deptid());

    System.out.println("\n ps= "+ps+"\n"+Emp);

    ps.executeUpdate();
    ps.close();
    con.close();
    System.out.println("Succesfully register !");
    }

    // To read data from the database 
    public static ArrayList<Employee> readEmployye() throws SQLException{
        ArrayList<Employee> empList = new ArrayList<Employee>();
        Connection con = DB.connect();
        String query=Query.select;
        Statement stm=con.prepareStatement(query); 
        System.out.println("\n st="+stm);

        ResultSet rs=stm.executeQuery(query);
        while (rs.next()) { 
            Employee emp=new Employee(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
            empList.add(emp);
        }
        stm.close();
        con.close();
        return empList;
}


public static void updateEmployee(int id,String name) throws SQLException{
    Connection con=DB.connect();
    String query=Query.update;
    PreparedStatement ps=con.prepareStatement(query);
    ps.setInt(2,id);
    ps.setString(1, name);

    System.out.println("\n st="+ps);
    ps.executeUpdate();
    ps.close();
    con.close();
}



public static void deleteEmployee(int id) throws SQLException{
    Connection con=DB.connect();
    String query=Query.delete;
    PreparedStatement pstm=con.prepareStatement(query);
    pstm.setInt(1,id);
    System.out.println("\n pstm="+pstm);

    pstm.executeUpdate();
    System.out.println("Employee deleted Successfully with id="+id);
    pstm.close();
    con.close();
}

}