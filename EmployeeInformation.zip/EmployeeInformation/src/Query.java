public class Query {
    static String insert="INSERT INTO EMPLOYEE(Emp_id,Emp_fname,Emp_lname,Emp_salary,Emp_deptid) VALUES (?,?,?,?,?)";
    static String select="Select * from employee";
    static String update="update employee set Emp_fname=? where Emp_id=?";
    static String delete="delete from employee where Emp_id=?";
}
