
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws SQLException{ 
    Scanner sc=new Scanner(System.in);
    boolean bl=true;
    while(bl){
    System.out.println("Welcome to my APP !");
    System.out.println("insert Data:1 \n Read data:2 \n update:3 \n delete:4 \n exit:5");
    int choice=sc.nextInt();

    if(choice<1||choice>5) return;
    
     switch (choice)
      {
         case 1 -> {
             System.out.println("Please enter the following details one by one !");
             System.out.println("Your id ");
             System.out.println("Your first Name ");
             System.out.println("Your Surname");
             System.out.println("Your salary ");
             System.out.println("Your department Id ");
             int Emp_id=sc.nextInt();
             sc.nextLine();
             String Emp_fname = sc.nextLine();
             String Emp_lname= sc.nextLine();
             int Emp_salary=sc.nextInt();
             int Emp_deptid=sc.nextInt();
             Employee emp=new Employee(Emp_id, Emp_fname, Emp_lname, Emp_salary, Emp_deptid);
             EmployeeDao.createEmployee(emp);
             
            }
         case 2 -> {
             ArrayList<Employee> List = EmployeeDao.readEmployye();
             for(Employee val:List){
                 System.out.println(val);
             }
            }
         case 3 -> {
             System.out.println("Enter Emp_id of which name you want to update:");
             int id=sc.nextInt();
             sc.nextLine();
             System.out.println("Enter the new name:");
             String Nname=sc.nextLine();
             EmployeeDao.updateEmployee(id, Nname);
             System.out.println("Updated Succesfully !");
             

            }
         case 4 -> {
             System.out.println("Enter EMPLOYEE ID to delete employee");
             int d=sc.nextInt();
             EmployeeDao.deleteEmployee(d);
            }

        case 5->{
            System.out.println("Thank you for visiting !");
            bl=false;
        }
     }    
    }
 }
}
